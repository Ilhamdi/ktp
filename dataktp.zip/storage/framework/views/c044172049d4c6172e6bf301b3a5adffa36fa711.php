
   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Rekap Data </div>
                <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                        <table class="datatable table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIK</th>
                                <th>Name</th>
                                <th>Jenis Kelamin</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                    </tbody>
                        </table>
                </div>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
            $(function() {
                $('.datatable').DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo e(route('dtktps.index')); ?>',
                    columns: [
                        {data: 'id'},
                        {data: 'nik'},
                        {data: 'nama'},
                        {data: 'jenisKelamin'},
                        {data: 'alamat'},
                        {data: 'action', name: 'action', orderable: true, searchable: true},
                    ]
                });
            });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dataktp\resources\views/admin/Home.blade.php ENDPATH**/ ?>