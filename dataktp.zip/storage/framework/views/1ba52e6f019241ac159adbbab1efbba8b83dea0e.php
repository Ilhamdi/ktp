
   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Data Kartu Penduduk 
                <?php 
                    if($data == null) 
                        { 
                ?>
                <a class="btn btn-primary" href="<?php echo e(route('dtktps.create')); ?>"><?php echo e(__('Entri Data')); ?></a>
                <?php 
                     } else { 
                ?>
                <a class="btn btn-primary" href="<?php echo e(route('dtktps.index')); ?>"><?php echo e(__('Edit Data')); ?></a>
                <?php     
                     }

                ?>
                </div>
                <div class="card-body">
                
                <?php 
                    if($data == null)
                     echo "Anda Belum Mengisi Data, Silahkan Entri Data Anda ";
                     else {  
                ?>
                    <div class="form-group row">
                        
                        <label for="propinsi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('NIK')); ?></label>
                        <div class="col-md-6">
                            <label for="propinsi" class="col-md-8 col-form-label text-md-left"><?php echo e($data->nik); ?></label>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <label for="propinsi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>
                        <div class="col-md-6">
                            <label for="propinsi" class="col-md-8 col-form-label text-md-left"><?php echo e($data->nama); ?></label>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <label for="propinsi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Jenis Kelamin')); ?></label>
                        <div class="col-md-6">
                            <label for="propinsi" class="col-md-8 col-form-label text-md-left"><?php echo e($data->jenisKelamin); ?></label>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <label for="propinsi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Status')); ?></label>
                        <div class="col-md-6">
                            <label for="propinsi" class="col-md-8 col-form-label text-md-left"><?php echo e($data->status); ?></label>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <label for="propinsi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('alamat')); ?></label>
                        <div class="col-md-6">
                            <label for="propinsi" class="col-md-8 col-form-label text-md-left"><?php echo e($data->alamat); ?></label>
                        </div>
                    </div>

                <?php 
                     }

                ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dataktp\resources\views/user/data_ktp.blade.php ENDPATH**/ ?>